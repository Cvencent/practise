package com.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class proxytest implements InvocationHandler {
     private Object subject;
	public proxytest(Object subject) {
    	 this.subject = subject;
     }
	@Override
	public Object invoke(Object object, Method method, Object[] args) throws Throwable {
		System.out.println(method.getName()+" ing...");
		Object result =  method.invoke(subject, args);
		System.out.println(method.getName()+" end...");
		return result;
	}

}
