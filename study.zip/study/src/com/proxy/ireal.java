package com.proxy;

public interface ireal {
   //void add(int a,int b);
   //void mul(int a,int b);
   Integer add(int a,int b);
   Integer mul(int a,int b);
}
