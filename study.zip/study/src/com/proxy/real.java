package com.proxy;

public class real implements ireal{

/*	@Override
	public void add(int a, int b) {
		System.out.println(a+b);
		
	}

	@Override
	public void mul(int a, int b) {
System.out.println(a*b);		
	}
*/
	@Override
	public Integer add(int a, int b) {
         return a+b;		
	}

	@Override
	public Integer mul(int a, int b) {
         return a*b;		
	}


}
