package com.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;


/*
 * ��̬������һ��ʵ��
 */
public class test {

	public static void main(String[] args) {
		ireal ex = new real();
		InvocationHandler handler = new proxytest(ex);
	ireal subject = (ireal)Proxy.newProxyInstance(handler.getClass().getClassLoader(),
				ex.getClass().getInterfaces(), handler);	
			System.out.println(subject.add(1,2));
			System.out.println(subject.mul(1,2));
			}

}
