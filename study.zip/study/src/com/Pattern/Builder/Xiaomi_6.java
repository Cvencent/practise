package com.Pattern.Builder;

public class Xiaomi_6 extends XIAOMI {

	@Override
	public float price() {
		return 1999;
	}

	@Override
	public String model() {
		
		return "xiaomi_6";
	}

}
