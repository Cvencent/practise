package com.Pattern.Builder;

public class Iphone_x extends Apple {

	@Override
	public float price() {
		
		return 6999;
	}

	@Override
	public String model() {
		
		return "iphone_x";
	}

}
