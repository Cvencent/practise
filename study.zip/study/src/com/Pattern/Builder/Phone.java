package com.Pattern.Builder;

public interface Phone {
      public String model();
      public float price();
      public Local local();
}