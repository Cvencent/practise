package com.Pattern.Builder;

public class China implements Local {

	@Override
	public String type() {
		
		return "China";
	}

}
