package com.Pattern.Builder;

/*
 * local为每个抽象类固定的组合
 */
public abstract class XIAOMI implements Phone {
      
	@Override
      public Local local() {
		return new China();  
      }
	
	@Override
	public abstract float price();
	
	@Override
	public abstract String model();
	
	
}
