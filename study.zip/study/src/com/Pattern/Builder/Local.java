package com.Pattern.Builder;

public interface Local {
    public String type();
}
