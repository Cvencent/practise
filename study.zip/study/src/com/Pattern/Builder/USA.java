package com.Pattern.Builder;

public class USA implements Local {

	@Override
	public String type() {
		
		return "America";
	}

}
