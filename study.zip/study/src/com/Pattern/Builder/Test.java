package com.Pattern.Builder;

public class Test {
/*
 * 建造者模式
 * 适合多个部分不变，改变总体组合的需求
 * 核心：接口，抽象类，子类
 */
	public static void main(String[] args) {
		Phone p1 = new Xiaomi_6();
		Phone p2 = new Iphone_x();
		System.out.println(p1.model()+"的产地是"+p1.local().type()+"\n价格为"+p1.price());
		System.out.println("================================");
		System.out.println(p2.model()+"的产地是"+p2.local().type()+"\n价格为"+p2.price());

	}

}
