package com.Pattern.singer1;

public class test {

	public static void main(String[] args) {
		singer1 s1 = singer1.getInstance();
		s1.example();
	}

}
