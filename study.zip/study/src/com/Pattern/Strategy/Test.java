package com.Pattern.Strategy;

public class Test {
/*
 * 策略模式
 * 1、算法可以自由切换。 
 * 2、避免使用多重条件判断。
 * 3、扩展性良好。
 * 
 */
	public static void main(String[] args) {
		 Context context = new Context(new Add());
		 System.out.println("10+2="+context.executeStrategy(10, 2));
		 context = new Context(new Sub());
		 System.out.println("10-2="+context.executeStrategy(10, 2));
		 context = new Context(new Mul());
		 System.out.println("10*2="+context.executeStrategy(10, 2));

	}

}
