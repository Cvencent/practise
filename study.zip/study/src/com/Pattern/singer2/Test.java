package com.Pattern.singer2;

public class Test {

	public static void main(String[] args) {
		Singer2 s2 = Singer2.getInstance();
		s2.example();

	}

}
