package com.Pattern.Chain_of_Responsibility;

public class Bigbank extends BankMangers {

	@Override
	public void process(int money) {
		if(money < 500000) {
			System.out.println(this.getClass().getName()+"����ҵ��");
		}
		else {
			System.out.println("��������ҪԤԼ");
		}

	}

}
