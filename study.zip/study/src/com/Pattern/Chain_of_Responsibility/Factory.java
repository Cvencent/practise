package com.Pattern.Chain_of_Responsibility;

public class Factory {
     public static BankMangers bankfactory() {
    	BankMangers smallbank = new Smallbank();
    	BankMangers middlebank = new MiddleBank();
    	BankMangers bigbank = new Bigbank();
    	
    	smallbank.setSuccessor(middlebank);
    	 middlebank.setSuccessor(bigbank);
    	 

    	 
	  return smallbank;
    	 }
}
