package com.Pattern.Chain_of_Responsibility;


public class Customer {
  private BankMangers bankmangers;


public void setbankmangers(BankMangers bankmangers) {
	this.bankmangers = bankmangers;
}
  public void request(int money) {
	  bankmangers.process(money);
  }

}
