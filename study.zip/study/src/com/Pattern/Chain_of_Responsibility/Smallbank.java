package com.Pattern.Chain_of_Responsibility;

public class Smallbank extends BankMangers {

	@Override
	public void process(int money) {
		if (money < 5000) {
			System.out.println(this.getClass().getName()+"����ҵ��");
		}
		else {
			successor.process(money);
		}

	}

}
