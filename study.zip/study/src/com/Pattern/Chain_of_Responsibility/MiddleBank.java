package com.Pattern.Chain_of_Responsibility;

public class MiddleBank extends BankMangers {

	@Override
	public void process(int money) {
		if(money < 50000) {
			System.out.println(this.getClass().getName()+"����ҵ��");
		}
		else{
			successor.process(money);
		}

	}

}
