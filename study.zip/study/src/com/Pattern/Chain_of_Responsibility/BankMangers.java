package com.Pattern.Chain_of_Responsibility;

public abstract class BankMangers {
     protected BankMangers successor;

	public void setSuccessor(BankMangers successor) {
		this.successor = successor;
	}
     public abstract void process(int money);
     
}
 