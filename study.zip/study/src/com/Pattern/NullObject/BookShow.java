package com.Pattern.NullObject;

public class BookShow implements Book {
    private String name;
    private String author;
    private int id;
	
    public BookShow(int id,String name,String author) {
    	this.id = id;
    	this.name = name;
    	this.author = author; 	
    }
    
	
	@Override
	public boolean isNull() {
		return false;
	}

	@Override
	public void show() {
		System.out.println(id+"**"+name+"**"+author);
	}

}
