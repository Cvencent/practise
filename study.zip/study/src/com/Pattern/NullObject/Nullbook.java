package com.Pattern.NullObject;

public class Nullbook implements Book {

	@Override
	public boolean isNull() {
		return true;
	}

	@Override
	public void show() {
		System.out.println("输入有误");

	}

}
