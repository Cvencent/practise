package com.Pattern.NullObject;

public class BookFactory {
    public Book bookchoose(int id) {
    	Book book ;
    	switch (id) {
		case 1:
			book = new BookShow(1,"设计模式","ROF");
			break;

		case 2:
			book = new BookShow(2,"空指针模式","设计模式");
		default:
			book = new Nullbook();
			break;
		}
    	
    	
    	
		return book;
    	
    	
    	
    	
    }
}
