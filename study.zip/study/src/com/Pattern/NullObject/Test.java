package com.Pattern.NullObject;
/*
 * 在空对象模式（Null Object Pattern）中，
 * 一个空对象取代 NULL 对象实例的检查。Null 对象不是检查空值，
 * 而是反应一个不做任何动作的关系。
 * 这样的 Null 对象也可以在数据不可用的时候提供默认的行为。
 */
public class Test {

	public static void main(String[] args) {
          BookFactory bf = new BookFactory();
          bf.bookchoose(1).show();
          bf.bookchoose(0).show();
	}

}
