package com.Pattern.NullObject;

public interface Book {
   public boolean isNull();
   public void show();
}
