package com.Pattern.Adapter;
/*
 * 适配器类
 * 通过有参构造器来创建对应的新对象
 */
public class Sizeadapter implements Size {
     Oversize os;

     public Sizeadapter(String size) {
    	 if(size.equals("M")) {
    		 os = new Middlesize();
    	 }
    	 if(size.equals("L")) {
    		 os = new Bigsize();
    	 }
     
     }
     /*
      * (non-Javadoc)
      * @see com.Pattern.Adapter.Size#smallsize(java.lang.String)
      * 在原方法中加入新操作
      */
	@Override
	public void smallsize(String size) {
		 if(size.equals("M")) {
    		 os.middlesize(size);
    	 }
    	 if(size.equals("L")) {
    		os.bigsize(size);
    	 }
	}

}
