package com.Pattern.Adapter;
/*
 * 给予大号一个操作
 */
public class Bigsize implements Oversize {

	@Override
	public void middlesize(String size) {
		//nothing to do

	}

	@Override
	public void bigsize(String size) {
		System.out.println("这是大号");

	}

}
