package com.Pattern.Adapter;
/*
 * 定义一个原接口无法实现的新接口
 * 中号与大号
 */
public interface Oversize {
      void middlesize(String size);
      void bigsize(String size);
}
