package com.Pattern.Adapter;
/*
 * 衣号选择类
 * 用来判断调用哪个操作
 * 整合新旧操作
 */
public class SizeChoose implements Size {
    Sizeadapter sd;
	
	@Override
	public void smallsize(String size) {
	  if (size.equals("S")) {
		  System.out.println("这是小号");
	  }	
	  else if (size.equals("M")||size.equals("L")) {
	     sd = new Sizeadapter(size);
	     sd.smallsize(size);
	  }  
	  else {
		  System.out.println("输入有误");
	  }

	}

}
