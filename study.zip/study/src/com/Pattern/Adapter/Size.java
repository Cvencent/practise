package com.Pattern.Adapter;
/*
 * 原接口
 * 只有小号
 */
public interface Size {
       void smallsize(String size);
}
