package com.Pattern.Adapter;
/*
 * 给予中号一个操作
 */
public class Middlesize implements Oversize {

	@Override
	public void middlesize(String size) {
		System.out.println("这是中号");

	}

	@Override
	public void bigsize(String size) {
		//nothing to do

	}

}
