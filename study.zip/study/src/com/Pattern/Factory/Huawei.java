package com.Pattern.Factory;

public class Huawei implements Phone {

	@Override
	public void characteristic() {
		System.out.println("����cpu");
		
	}

}
