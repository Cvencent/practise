package com.Pattern.Factory;

public interface Phone {
     void characteristic();

}
