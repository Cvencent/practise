package com.Pattern.Factory;

public class Test {
   public static void main(String[] args) {
	   Factory factory = new Factory();
	   /*
	    * �ù���������ʵ��
	    */
	   Phone p1 = factory.getcharacteristic("OLED��Ļ");
	   System.out.println(p1.getClass());
	   
	   Phone p2 = factory.getcharacteristic("����cpu");
       System.out.println(p2.getClass());
       
       Phone p3 = factory.getcharacteristic("iosϵͳ");
       System.out.println(p3.getClass());
   }
}
