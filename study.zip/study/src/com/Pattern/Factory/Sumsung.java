package com.Pattern.Factory;

public class Sumsung implements Phone {

	@Override
	public void characteristic() {
		System.out.println("oled��Ļ");

	}

}
