package com.Pattern.Factory;

public class Apple implements Phone {

	@Override
	public void characteristic() {
		System.out.println("iosϵͳ");

	}

}
