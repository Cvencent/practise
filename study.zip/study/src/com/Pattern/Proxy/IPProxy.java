package com.Pattern.Proxy;

public interface IPProxy {

}
