package com.Pattern.Template;

public class HUAWEI extends CreatePhone {

	@Override
	protected void advance_booking() {

	}

	@Override
	protected void publish() {
		System.out.println("华为公司发布");

	}

	@Override
	protected void produce() {
		System.out.println("华为代工厂生产");

	}
	@Override
	protected boolean wants() {
		return false;
		
	}

}
