package com.Pattern.Template;

public abstract class CreatePhone {
    /*
     * 模板方法，防止子类恶意修改
     */
     public final void CreatePhoneTemplate() {
    	 /*
    	  * 设计手机
    	  */
    	 design();
    	 /*
    	  * 生产手机
    	  */
    	 produce();
    	 /*
    	  * 发布手机
    	  */
    	 publish();
    	 /*
    	  * 预售手机
    	  */
    	 if( wants()) {
    	 advance_booking();
    	 }
    	 /*
    	  * 售卖手机
    	  */
    	 sell();
     }

      /*
       * hook函数
       */
     protected boolean wants() {
			return true;
	}


	protected abstract void advance_booking();

	protected abstract void publish();

    protected abstract void produce();

	private void design() {
		System.out.println("设计手机");
		
	}
	private void sell() {
		System.out.println("开始售卖");
		
	}
     
}
