package com.Pattern.Flyweight;

public interface Shape {
     void draw();
}
