package com.Pattern.MVC;



public class View {

	public static void main(String[] args) {
	

	}

}
