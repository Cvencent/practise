package com.Pattern.MVC;
/*
 *  操作层
 */
public class Control {
   Model m = new Model();
}
