package com.Pattern.Filter;

import java.util.List;
/*
 * 定义标准的接口
 */
public interface Criteria {
  public List<People> meetCriteria(List<People> people);
}
