package com.Pattern.Filter;

import java.util.List;
/*
 *   过滤and事件
 */
public class Andcriteria implements Criteria {
	private Criteria criteria;
    private Criteria othercriteria;
    
    public Andcriteria(Criteria criteria,Criteria othercriteria) {
		this.criteria = criteria;
		this.othercriteria = othercriteria;
	}
	@Override
	public List<People> meetCriteria(List<People> people) {
		List<People> first = criteria.meetCriteria(people);
		List<People> second = othercriteria.meetCriteria(first);
		return second;
	}

}
