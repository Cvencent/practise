package com.Pattern.Filter;

import java.util.List;
/*
 * 过滤or事件
 * 
 */
public class Orcriteria implements Criteria {
    private Criteria criteria;
    private Criteria othercriteria;
    
    public Orcriteria(Criteria criteria,Criteria othercriteria) {
		this.criteria = criteria;
		this.othercriteria = othercriteria;
	}
	@Override
	public List<People> meetCriteria(List<People> people) {
		List<People> first = criteria.meetCriteria(people);
		List<People> second = othercriteria.meetCriteria(people);
		for (People people2 : second) {
			if(!first.contains(people2)) {
				first.add(people2);
			}
		}
 		return first;
	}

}
