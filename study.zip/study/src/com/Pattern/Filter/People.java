package com.Pattern.Filter;

public class People {

private String name;
   private String sex;
   private String status;
   
   public People(String name,String sex,String status) {
   this.name = name;
   this.sex = sex;
   this.status = status;
   }
   public String getName() {
	   return name;
   }
   
   public String getSex() {
	   return sex;
   }
   public String getStatus() {
	   return status;
   }
   
   
}
