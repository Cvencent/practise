package com.Pattern.Filter;

import java.util.ArrayList;
import java.util.List;

public class Criteriamale implements Criteria {

	@Override
	public List<People> meetCriteria(List<People> people) {
		List<People> male = new ArrayList<People>();
		for (People people2 : people) {
		    if(people2.getSex().equals("Male")) {
		    	male.add(people2);
		    }	
		}
		return male;
	}

}
