package com.Pattern.Filter;

import java.util.ArrayList;
import java.util.List;

public class Criteriasingle implements Criteria {

	@Override
	public List<People> meetCriteria(List<People> people) {
		List<People> single = new ArrayList<People>();
		for (People people2 : people) {
		    if(people2.getStatus().equals("Single")) {
		    	single.add(people2);
		    }	
		}
		return single;
	}

}
