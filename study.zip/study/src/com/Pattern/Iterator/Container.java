package com.Pattern.Iterator;

public interface Container {
     public Iterator getIterator();
}
