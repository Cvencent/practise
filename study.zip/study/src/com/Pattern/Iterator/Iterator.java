package com.Pattern.Iterator;

public interface Iterator {
       public boolean hasnext();
       public Object next();
}
