package com.Pattern.Iterator;

public class NameIterator implements Container {
  String name[] = {"a","b","c","d"};
	@Override
	public Iterator getIterator() {
		return new realIterator();
	}
	
	
	
	private class realIterator implements Iterator{
      int index;
		
		@Override
		public boolean hasnext() {
			if(index<name.length) {
				return true;
			}
			return false;
		}

		@Override
		public Object next() {
			if(this.hasnext()) {
				return name[index++];
			}
			return null;
		}
		
	}

}
