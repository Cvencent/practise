package com.tcp;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class server2 {

	public static void main(String[] args) throws IOException {
			
				while(true) {
				@SuppressWarnings("resource")
				Socket socket =  new ServerSocket(9999).accept();//��������ʼ�����˿�
				Thread serverthread = new serverThread(socket);
				serverthread.run();

	}

}}
