package com.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class cliebt {
	public static void main(String[] args) {
		 try {
			 Socket socket = new Socket("localhost",9999);//���ӱ���9999�˿ڷ�������
			 OutputStream os = socket.getOutputStream();//��������ַ���
			 PrintWriter  pw = new PrintWriter(os);//���������װ�ɴ�ӡ��
			 pw.write("���ǿͻ���");
			 pw.flush();//ˢ�´�ӡ��
	socket.shutdownOutput();
			 InputStream is = socket.getInputStream();
			 InputStreamReader isr = new InputStreamReader(is);
			 BufferedReader br = new BufferedReader(isr);
			 String a = null;
			while((a = br.readLine())!= null) {
				System.out.println("�ҵ���Ϣ"+a);
			}
			br.close();
			isr.close();
			 is.close();
			 pw.close();
			 os.close();
			 socket.close();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
