package com.Reflect;

import java.lang.reflect.Method;

/*
 * ��������
 */
public class Test3 {

	public static void main(String[] args) {
		A a = new A();
		Class c =  a.getClass();
		try {
			Method m = c.getMethod("add",new Class[] {int.class ,int.class });
			/*
			 * Method m = c.getMethod("add",int.class ,int.class);
			 */
			
			m.invoke(a,new Object[]{10,20});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
            
	}

}

class A {
	public void add(int a,int b) {
		System.out.println(a+b);
	}
	
	
	
}
