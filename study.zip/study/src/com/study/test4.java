package com.study;
/*
 * ð������
 */
public class test4 {
public static void main(String[] args) {
	int[] num = new int[] {2,3,5,1,6,4};
	test(num);}
	public static void test(int[] temp)  {
		for(int i = 0;i<temp.length-1;i++) {
			for(int j = i+1;j<temp.length;j++) {
				if(temp[i]>temp[j]) {
					int a = temp[j];
					temp[j] = temp[i];
					temp[i] = a;
				}
			}
		}
		for(int a : temp) {
			System.out.println(a);
		}
	}

}
