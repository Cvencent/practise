package com.study;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
/*
 * ��̬�����ڶ���ʵ�ַ���
 */


public class test5 {
	public static void main(String[] args) {
		   test5 a=  new test5();
		   System.out.println(a.proxy().add(1, 2));
		}

 public interface itest5{
	 int add(int a,int b);
	 int mul(int a,int b);
	 }
 public class atest5 implements itest5{

	@Override
	public int add(int a, int b) {
		return a+b;
	}

	@Override
	public int mul(int a, int b) {
		 return a*b;
	}
	 
 }
 public itest5 proxy(){
	 itest5 a = new atest5();
	 itest5 b = (itest5)Proxy.newProxyInstance
			 (atest5.class.getClassLoader(), new Class[]{itest5.class},
			 new InvocationHandler() {
				
				@Override
				public Object invoke(Object proxy, Method method, Object[] args)
						throws Throwable {
					System.out.println("the method is "+method.getName());
					Object result = method.invoke(a, args);
					return result;
				}
			});
	return b;
	 
 }
	 }
