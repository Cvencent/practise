package com.study;
/*
 * foreachѭ����ά����
 */
public class test2 {

	public static void main(String[] args) {
		int[][] num = new int[][] {{1,2,3},{4,5,6},{7,8,9}};
		for(int[] a :num) {
			for(int b :a) {
				System.out.println(b);
			}
		}

	}

}
