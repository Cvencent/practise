package com.study;

/*

����ת��

*/
public class test3 {

	public static void main(String[] args) {
		int[] data = new int [] {1,2,3,4,5};
		max(data);
	}
	public static void max(int[] temp) {
	int num = temp.length/2;
	int head = 0;
	int tail = temp.length- 1;
	for(int i = 0;i< num;i++) {
	 int a	=  temp[head];
	 temp[head] = temp[tail] ;
	 temp[tail] = a;
	 head++;
	 tail--;
	}
	for(int a : temp) {
		System.out.println(a);
	}
	
	}
	

}
