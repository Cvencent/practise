package com.Xml;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class Test2 {
/*
 * SAX����
 */
	public static void main(String[] args) {
		try {
			//���SAXParserFactoryʵ��
			SAXParserFactory spf = SAXParserFactory.newInstance();
			SAXParser sp =  spf.newSAXParser();
		  Test2 t = new Test2();
		  Test2.SAXParserHandler sph= t.new SAXParserHandler();
			sp.parse("book.xml",sph );
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	 //DefaultHandler��
	  class SAXParserHandler extends DefaultHandler{
		/*
		 * ����xml�ļ��Ŀ�ʼ��ǩ
		 */
		@Override
		public void startElement(String uri, String localName, String qName, Attributes attributes)
				throws SAXException {
			super.startElement(uri, localName, qName, attributes);
			if(qName.equals("book")) {
				//��֪bookԪ�������Ե�����
				//String value = attributes.getValue("id");
				for(int i = 0;i<attributes.getLength();i++) {
					System.out.println(attributes.getQName(i)+"==="+attributes.getValue(i));
				}
			}
			else if (!qName.equals("book")&&!qName.equals("bookstore")) {
				System.out.print("�ڵ���"+qName);
			}
		}
		/*
		 * ����xml�ļ��Ľ�����ǩ
		 * 
		 */
		@Override
		public void endElement(String uri, String localName, String qName) throws SAXException {
			super.endElement(uri, localName, qName);
			
		}
		/*��־������ʼ
		 */
		@Override
		public void startDocument() throws SAXException {
		
			super.startDocument();
			System.out.println("������ʼ");
		}
		/*��־��������
		 */
		@Override
		public void endDocument() throws SAXException {
			
			super.endDocument();
			System.out.println("��������");
		}
		//��ñ�ǩ����
		@Override
		public void characters(char[] ch, int start, int length) throws SAXException {
			super.characters(ch, start, length);
			String s = new String(ch, start, length);
			//s�ַ��������ո��Ϊ��   
			if(!s.trim().equals("")) {
			System.out.println("******"+"�ڵ�ֵ"+s);
			}
		}
		
	}

}
