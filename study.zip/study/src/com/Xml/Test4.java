package com.Xml;

public class Test4 {
/*
 * JDOM
 */
	public static void main(String[] args) {
		

	}

}
