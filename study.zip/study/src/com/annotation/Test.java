package com.annotation;
@Description(author = "bb")
public class Test {

	@Description(author = "aaa")
	public static void main(String[] args) {
		Test t = new Test();
		Test.c c1 = t.new c();
		c1.annotationtest();

	}
	@Description(author = "aa")
	class c{
		public void annotationtest() {
			String desc = "bb";
			String author = "aa";
			int age = 18;
			System.out.println(desc);
			System.out.println(age);
			System.out.println(author);
		}
	}

}
