package com.annotation;

import java.lang.reflect.Method;

public class Analysis {

	public static void main(String[] args) {
		try {
			Class c = Class.forName("com.annotation.Test");
			//找到类上面的注解
			//判断是否存在注释
			boolean is= c.isAnnotationPresent(Description.class);
			if(is) {
				Description d = (Description)c.getAnnotation(Description.class);
				System.out.println(d.author());
				System.out.println(d.age());
			}
			//找到方法上面的注解
			Method[] ms = c.getMethods();
			for(Method m : ms) {
				boolean ishave = m.isAnnotationPresent(Description.class);
				if(ishave) {
					Description dd = (Description)m.getAnnotation(Description.class);
				    System.out.println(dd.author());
				}
			}
		} catch (Exception e) {
           e.printStackTrace();
		}
		

	}

}
