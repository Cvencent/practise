package com.RegularExpression;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * 正则表达式测试
 */
public class Test1 {

	public static void main(String[] args) {
		      String content = "I am noob " +
		        "from runoob.com.";
		      String pattern = ".*runoo+b.*";
		        //first
		      boolean isMatch = Pattern.matches(pattern, content);
		      System.out.println("字符串中是否包含了 'runoob' 子字符串? " + isMatch);
		      
		      /*
		       * second
		       * 
		       * Matcher xx =  matcher(CharSequence input) 
                                               创建一个匹配器，匹配给定的输入与此模式。  
                 boolean xx  =  matches() 
                                                尝试将整个区域与模式进行匹配。 
		       */
		      Pattern p = Pattern.compile("a*b");
		      Matcher m = p.matcher("aaaaab");
		      boolean b = m.matches();
		      System.out.println(b);
		      
	}

}
