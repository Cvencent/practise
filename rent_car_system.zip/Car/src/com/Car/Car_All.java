package com.Car;

public class Car_All extends Cars{
	Car_All(String name,int price,int volme,int thing){
    	this.name =name;
    	this.price = price;
    	this.thing = thing;
    	this.volme = volme;
	}
}