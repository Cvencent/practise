package com.Car;

public class Cars {
	  public String name;
	    public int price;
	    public int volme ;
	    public int thing ;
	    Cars(){}
}
