package com.Car;

public class Car_Huo extends Cars {
	int num;
	int[] thing1;
	Car_Huo(int num){
		this.num= num;
		this.thing1= new int[num];
	}
	Car_Huo(String name,int price,int thing){
    	this.name =name;
    	this.price = price;
    	this.thing = thing;
}
	public Car_Huo() {
		// TODO Auto-generated constructor stub
	}
	public int all() {
		int m = 0;
		for (int i = 0;i<num;i++) {
			m += thing1[i];
		}
		return m;
	}
	}

