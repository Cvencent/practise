package com.Car;

public class Car_Passage extends Cars{
	int num;
	int[] passage;
	  Car_Passage() {}
	  Car_Passage(int num){
			this.num= num;
			this.passage = new int[num];
	  }
	   Car_Passage(String name,int price,int volme){
	    	this.name =name;
	    	this.price = price;
	    	this.volme = volme;
	    }
	   public int all() {
		   int m=0;
		   for(int i = 0 ;i<num;i++) {
			   m += passage[i];
		   }
		   return m;
	   }
}
