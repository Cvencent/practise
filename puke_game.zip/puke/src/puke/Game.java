package puke;

public class Game {
Puke id1;
Puke id2;
Puke id3;
Puke id4;
Game(Puke id1,Puke id2,Puke id3,Puke id4){
	this.id1 = id1;
	this.id2 = id2;
	this.id3 = id3;
	this.id4 = id4;
	}
}
