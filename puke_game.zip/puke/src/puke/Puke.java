package puke;

public class Puke implements Comparable<Puke>{
String zl;
String num;

public Puke(String zl,String num) {
	this.zl = zl;
	this.num = num;
	}
Puke(){
	
}
//public void add() {
//	Iterator<Puke> it = Puke.iterator();
//	while(it.hasNext()) {
//		Puke num2 = it.next();
//		System.out.print(num2.zl+num2.num+" ");
//	}
@Override
public int compareTo(Puke arg0) {
	return this.num.compareTo(arg0.num);
}
//public List Pukeadd() {
//	List<Puke> num4 = new ArrayList<Puke>();
//	num4.add(new Puke("÷��","1"));
//    num4.add(new Puke("����","2"));
//    num4.add(new Puke("����","3"));
//    num4.add(new Puke("����","4"));
//    return num4;
//}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((num == null) ? 0 : num.hashCode());
	result = prime * result + ((zl == null) ? 0 : zl.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Puke other = (Puke) obj;
	if (num == null) {
		if (other.num != null)
			return false;
	} else if (!num.equals(other.num))
		return false;
	if (zl == null) {
		if (other.zl != null)
			return false;
	} else if (!zl.equals(other.zl))
		return false;
	return true;
}

}
