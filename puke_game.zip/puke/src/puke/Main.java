package puke;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
public class Main {
	public static void main(String[] args) {
		List<Puke> num1 = new ArrayList<Puke>();
		List<Puke> num2 = new ArrayList<Puke>();
		List<Puke> num3 = new ArrayList<Puke>();
		List<Puke> numcomparate = new ArrayList<Puke>();
		String[] suit = {"÷��","����","����","����"};
		String[] point = {"2","3","4","5","6","7","8","9",
				"10","J","Q","K","A",};
		for(int i = 0;i<13;i++) {
		for(int j = 0;j<4;j++) {
			numcomparate.add(new Puke(suit[j],point[i]));
		}
		}
		for(int i = 0;i<13;i++) {
			for(int j = 0;j<4;j++) {
				num1.add(new Puke(suit[j],point[i]));
			}
			}
		System.out.println("-------����һ���˿���-------");
//		for (Puke puke2 : num1) {
//			System.out.print(puke2.zl+puke2.num+" ");
//		}
        System.out.println("---------��������--------");
        for(int i = 0; i <300;i++) {
        int random = new Random().nextInt(52);
        int random2 = new Random().nextInt(52);
        Puke num4 =  num1.get(random);
        num1.remove(random);
        num1.add(random2,num4);
    }
       Player player = new Player();
       player.playeradd();
       System.out.println("���һ����");
       num2.add(num1.get(0));
       System.out.println("��Ҷ�����");
       num3.add(num1.get(1));
       System.out.println("���һ����");
       num2.add(num1.get(2));
       System.out.println("��Ҷ�����");
       num3.add(num1.get(3));
       if(numcomparate.indexOf(num2.get(0))>numcomparate.indexOf(num3.get(0))) {
    	   if(numcomparate.indexOf(num2.get(0))>numcomparate.indexOf(num3.get(1))) {
    		   System.out.println("Ӯ���ǣ����һ");
    	   }else {
               if(numcomparate.indexOf(num2.get(1))<numcomparate.indexOf(num3.get(1))) {
            	   System.out.println("Ӯ���ǣ���Ҷ�");
               }else {
            	   System.out.println("Ӯ���ǣ����һ");
               }
               }
    		  
    	   }
       if(numcomparate.indexOf(num2.get(0))<numcomparate.indexOf(num3.get(0))) {
    	   if(numcomparate.indexOf(num2.get(1))<numcomparate.indexOf(num3.get(0))) {
    		   System.out.println("Ӯ���ǣ���Ҷ�");
    	   }else {
    		   if(numcomparate.indexOf(num2.get(1))<numcomparate.indexOf(num3.get(1))) {
    			   System.out.println("Ӯ���ǣ���Ҷ�");
    		   }
    		   else {
    			   System.out.println("Ӯ���ǣ����һ");
    		   }
    		   
    		   }
    	   }
//       for (Puke puke2 : numcomparate) {
//			System.out.print(puke2.zl+puke2.num+" ");
//		}
//    	   
       
       System.out.println("���һ�����ƣ�"+num2.get(0).zl+num2.get(0).num+" "+num2.get(1).zl+num2.get(1).num);
       System.out.println("��Ҷ������ƣ�"+num3.get(0).zl+num3.get(0).num+" "+num3.get(1).zl+num3.get(1).num);

		

}
}
